package dos;

public class ConsoleDemo {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
